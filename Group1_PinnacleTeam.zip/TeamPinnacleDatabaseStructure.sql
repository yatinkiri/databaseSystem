/***********************************
Group 1 (Pinnacle Team)
Student Recruitment Database Systems
************************************/

/*DATABASE SET-UP*/
DROP DATABASE IF EXISTS pinnacle;
CREATE DATABASE pinnacle;
USE pinnacle;

/*DATABASE STRUCTURE*/
CREATE TABLE DEPARTMENT (
    departmentID CHAR (4), -- "ITCS", "MATH" etc
    departmentName VARCHAR (50), -- "Computer Science", "Mathematics" etc
    departmentDescription VARCHAR (250),
    PRIMARY KEY (departmentID)
);
CREATE TABLE PROFESSOR (
	professorName VARCHAR (50),
    professorDegreeDetail VARCHAR (100),
    professorInterests VARCHAR (100),
    PRIMARY KEY (professorName)
);
CREATE TABLE RESEARCH (
	researchAreaName VARCHAR (20),
    researchLab VARCHAR (20),
    researchDescription VARCHAR (250),
    PRIMARY KEY (researchAreaName)
);
CREATE TABLE CURRENT_RA (
	researchAreaName VARCHAR (20),
    researchAssistantName VARCHAR (50),
    PRIMARY KEY (researchAreaName, researchAssistantName),
    FOREIGN KEY (researchAreaName) REFERENCES RESEARCH(researchAreaName)
);
CREATE TABLE DEGREE (
	departmentID CHAR (4) NOT NULL,
	degreeName VARCHAR (25), -- BSCS,MSCS,PHDCS,BACS,BSMATH,BAMATH etc
    degreeDescription VARCHAR (250),
    fallDeadline DATETIME,
    springDeadline DATETIME,
    credits SMALLINT UNSIGNED,
    startedSemester VARCHAR (15), -- "Spring 2020", "Fall 2045"
    totalIntake SMALLINT UNSIGNED,
    PRIMARY KEY (degreeName),
    FOREIGN KEY (departmentID) REFERENCES DEPARTMENT (departmentID) ON DELETE CASCADE
);
CREATE TABLE COURSE_CATALOG (
	degreeName VARCHAR (25) NOT NULL,
    courseName VARCHAR (25),
    creditValue SMALLINT UNSIGNED,
    PRIMARY KEY (degreeName,courseName),
    FOREIGN KEY (degreeName) REFERENCES DEGREE (degreeName) ON DELETE CASCADE
);
CREATE TABLE DEGREE_REQUIREMENTS (
    degreeName VARCHAR (25),
    degreeRequirementID SMALLINT UNSIGNED,
    startTerm VARCHAR (15),
    endTerm VARCHAR (15),
    minGPA FLOAT (4, 2),
    educationLevel CHAR (2), -- HS,UD,MS
    PRIMARY KEY (degreeName,degreeRequirementID),
    FOREIGN KEY (degreeName) REFERENCES DEGREE (degreeName)
);
CREATE TABLE DRTESTSCORE (
    degreeName VARCHAR (25),
    testName CHAR (3), -- SAT,ACT,GRE,TFL
    scoreVerbal FLOAT (5, 2) UNSIGNED,
    scoreQuant FLOAT (5, 2) UNSIGNED,
    scoreAwa FLOAT (5, 2) UNSIGNED,
    PRIMARY KEY (degreeName,testName),
    FOREIGN KEY (degreeName) REFERENCES DEGREE (degreeName) ON DELETE CASCADE
);
CREATE TABLE RECRUITER (
	recruiterID BIGINT UNSIGNED AUTO_INCREMENT,
    userName VARCHAR (15),
    recoveryQuestion VARCHAR (100) NOT NULL, -- encode
    recoveryAnswer VARCHAR (100) NOT NULL, -- encode
    pass VARCHAR (44) NOT NULL, -- SHA-256=VARCHAR(44)
	email VARCHAR (256) NOT NULL, -- Email addresses, while not probable, can be upto 256 characters long: http://en.wikipedia.org/wiki/Email_address
    firstName VARCHAR (20) NOT NULL,
    middleName VARCHAR (20),
    lastName VARCHAR (20) NOT NULL,
    departmentID CHAR (4),
    PRIMARY KEY (recruiterID),
    FOREIGN KEY (departmentID) REFERENCES DEPARTMENT (departmentID) -- Works For Relationship with Department
        ON DELETE CASCADE
);
CREATE TABLE STUDENT (
	studentID BIGINT UNSIGNED AUTO_INCREMENT,
    userName VARCHAR (15), -- first initial, first 5 letters of last name, number to distinguish further
    recoveryQuestion VARCHAR (100) NOT NULL, -- encode
    recoveryAnswer VARCHAR (100) NOT NULL, -- encode
    pass VARCHAR (44) NOT NULL, -- SHA-256=VARCHAR(44)
    studentStatus CHAR (2), -- IS (InState), OS(OutState), IN(International)
    email VARCHAR (256) NOT NULL, -- Email addresses, while not probable, can be upto 256 characters long: http://en.wikipedia.org/wiki/Email_address
    firstName VARCHAR (20) NOT NULL,
    lastName VARCHAR (20) NOT NULL,
    gpa FLOAT (4,2),
    lastLogin DATETIME,
    numberOfLogins INT UNSIGNED,
    PRIMARY KEY (studentID)
);
CREATE TABLE INTERESTED_DEGREE (
	studentID BIGINT UNSIGNED,
    degreeName VARCHAR (25),
    PRIMARY KEY (studentID,degreeName),
    FOREIGN KEY (studentID) REFERENCES STUDENT (studentID) ON DELETE CASCADE
);
CREATE TABLE INTERESTED_RESEARCH (
	studentID BIGINT UNSIGNED,
    researchAreaName VARCHAR (20),
    PRIMARY KEY (studentID,researchAreaName),
    FOREIGN KEY (studentID) REFERENCES STUDENT (studentID)
);
CREATE TABLE ADDRESS (
    addressID BIGINT UNSIGNED AUTO_INCREMENT,
    zipCode VARCHAR (10),
    city VARCHAR (20),
    state VARCHAR (20),
    country VARCHAR (20),
    street VARCHAR (40),
    PRIMARY KEY (addressID)
);
CREATE TABLE TEST (
	studentID BIGINT UNSIGNED,
    testID BIGINT UNSIGNED,
    testName CHAR (3), -- SAT,ACT,GRE,TFL
    testDate DATE,
    scoreVerbal FLOAT (5, 2) UNSIGNED,
    scoreQuant FLOAT (5, 2) UNSIGNED,
    scoreAwa FLOAT (5, 2) UNSIGNED,
    PRIMARY KEY (testID),
	FOREIGN KEY (studentID) REFERENCES STUDENT(studentID) ON DELETE CASCADE
);
CREATE TABLE INTERNAL_STUDENT (
	studentID BIGINT UNSIGNED,
    onCampusJob CHAR (2), -- RA, TA
    classStanding VARCHAR (32),
    currentCredits MEDIUMINT UNSIGNED,
    expectedGraduationDate DATE,
    startTerm VARCHAR (15),
    PRIMARY KEY (studentID),
    FOREIGN KEY (studentID) REFERENCES STUDENT(studentID)
);
CREATE TABLE EXTERNAL_STUDENT (
	studentID BIGINT UNSIGNED,
    jobExperience VARCHAR (50),
    jobDescription VARCHAR (250),
    extraCurricular VARCHAR (32),
	PRIMARY KEY (studentID),
    FOREIGN KEY (studentID) REFERENCES STUDENT(studentID)
);

CREATE TABLE DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (
	departmentID CHAR (4),
	professorName VARCHAR (50),
	researchAreaName VARCHAR (20),
    PRIMARY KEY (departmentID, professorName, researchAreaName),
    FOREIGN KEY (departmentID) REFERENCES DEPARTMENT (departmentID) ON DELETE CASCADE,
    FOREIGN KEY (professorName) REFERENCES PROFESSOR (professorName) ON DELETE CASCADE,
    FOREIGN KEY (researchAreaName) REFERENCES RESEARCH (researchAreaName) ON DELETE CASCADE
);
CREATE TABLE STUDENT_LIVES_ADDRESS (
	studentID BIGINT UNSIGNED NOT NULL,
	addressID BIGINT UNSIGNED NOT NULL,
	PRIMARY KEY (studentID,addressID),
    FOREIGN KEY (studentID) REFERENCES STUDENT(studentID) ON DELETE CASCADE,
    FOREIGN KEY (addressID) REFERENCES ADDRESS(addressID) ON DELETE CASCADE
);
CREATE TABLE RECRUITER_RECRUITS_STUDENT (
	recruiterID BIGINT UNSIGNED,
    studentID BIGINT UNSIGNED,
    recruitStatus CHAR (1), -- I for incomplete or C for complete
    PRIMARY KEY (recruiterID,studentID,recruitStatus),
    FOREIGN KEY (recruiterID) REFERENCES RECRUITER (recruiterID),
    FOREIGN KEY (studentID) REFERENCES STUDENT (studentID) ON DELETE CASCADE
);
CREATE TABLE STUDENT_SEARCHFOR_DEPARTMENT (
	studentID BIGINT UNSIGNED,
    departmentID CHAR (4),
    PRIMARY KEY (studentID,departmentID),
    FOREIGN KEY (studentID) REFERENCES STUDENT (studentID) ON DELETE CASCADE,
    FOREIGN KEY (departmentID) REFERENCES DEPARTMENT (departmentID) ON DELETE CASCADE
);
CREATE TABLE STUDENT_APPLIES_DEGREE_RECRUITER (
	studentID BIGINT UNSIGNED,
    degreeName VARCHAR (25),
    recruiterID BIGINT UNSIGNED,
    reviewStatus CHAR (1), -- I for incomplete, C for complete
    startTerm VARCHAR (15),
    applicationStatus CHAR (1), -- I for incomplete, C for complete
    admissionDecision CHAR (1), -- A for admitted, N for no decision, D for not accepted
    PRIMARY KEY (studentID,degreeName,recruiterID),
    FOREIGN KEY (studentID) REFERENCES STUDENT (studentID) ON DELETE CASCADE,
    FOREIGN KEY (degreeName) REFERENCES DEGREE (degreeName) ON DELETE CASCADE,
    FOREIGN KEY (recruiterID) REFERENCES RECRUITER (recruiterID)
);

/* Team 1 Insert Statement*/
INSERT INTO DEPARTMENT (departmentID,departmentName,departmentDescription) VALUES ("ITCS", "Computer Science", "Computer Science Department");
INSERT INTO DEPARTMENT (departmentID,departmentName,departmentDescription) VALUES ("ITIS", "Information Systems", "Software and Information Systems Department");
INSERT INTO DEPARTMENT (departmentID,departmentName,departmentDescription) VALUES ("GEOG", "Geography", "Geography Department");
INSERT INTO DEPARTMENT (departmentID,departmentName,departmentDescription) VALUES ("DSBA", "Data Sc. & Bus. Analytic", "Data Science and Business Analytic Department");

INSERT INTO PROFESSOR (professorName,professorDegreeDetail,professorInterests) VALUES ("Wlodek Zadrozny","Ph. D.","Text Mining");
INSERT INTO PROFESSOR (professorName,professorDegreeDetail,professorInterests) VALUES ("Kalpathi Subramanian","Ph. D.","Computer Graphics");
INSERT INTO PROFESSOR (professorName,professorDegreeDetail,professorInterests) VALUES ("Ali Naderan","Ph. D.","Spatio-Temporal Data");
INSERT INTO PROFESSOR (professorName,professorDegreeDetail,professorInterests) VALUES ("Kristine Dohner","Ph. D.","Security");

INSERT INTO RESEARCH (researchAreaName,researchLab,researchDescription) VALUES ("Text Mining","CS Text Mining Lab","Text Mining for big data.");
INSERT INTO RESEARCH (researchAreaName,researchLab,researchDescription) VALUES ("Big Data","BD Lab","Exploring big data.");
INSERT INTO RESEARCH (researchAreaName,researchLab,researchDescription) VALUES ("GIS","Geo-GIS-Lab","Spatial Science related studies.");
INSERT INTO RESEARCH (researchAreaName,researchLab,researchDescription) VALUES ("Security","Cyber-Security-Lab","Security studies.");

INSERT INTO CURRENT_RA (researchAreaName,researchAssistantName) VALUES ("Text Mining","Asghar Sharafi");
INSERT INTO CURRENT_RA (researchAreaName,researchAssistantName) VALUES ("Big Data","David Kale");
INSERT INTO CURRENT_RA (researchAreaName,researchAssistantName) VALUES ("GIS","Jean Lee");
INSERT INTO CURRENT_RA (researchAreaName,researchAssistantName) VALUES ("Security","Walid Altayebi");

INSERT INTO DEGREE (departmentID,degreeName,degreeDescription,fallDeadline,springDeadline,credits,startedSemester,totalIntake) VALUES ("ITCS","MSCS","Master of Science in Computer Science","2015-6-15","2015-10-15","30","Fall 2001","45");
INSERT INTO DEGREE (departmentID,degreeName,degreeDescription,fallDeadline,springDeadline,credits,startedSemester,totalIntake) VALUES ("ITIS","MSIS","Master of Science in Information Systems","2015-6-15","2015-10-15","30","Fall 2008","45");
INSERT INTO DEGREE (departmentID,degreeName,degreeDescription,fallDeadline,springDeadline,credits,startedSemester,totalIntake) VALUES ("GEOG","MSGIS","Master of Science in GIS","2015-6-1","2015-10-1","30","Fall 2008","40");
INSERT INTO DEGREE (departmentID,degreeName,degreeDescription,fallDeadline,springDeadline,credits,startedSemester,totalIntake) VALUES ("DSBA","MSDSBA","Master of Science in Master of Science in Data Science and Business Analytic","2015-7-1","2015-11-15","30","Fall 2011","45");

INSERT INTO COURSE_CATALOG (degreeName,courseName,creditValue) VALUES ("MSCS","Machine Learning","3");
INSERT INTO COURSE_CATALOG (degreeName,courseName,creditValue) VALUES ("MSIS","Security","3");
INSERT INTO COURSE_CATALOG (degreeName,courseName,creditValue) VALUES ("MSGIS","GIS I","3");
INSERT INTO COURSE_CATALOG (degreeName,courseName,creditValue) VALUES ("MSDSBA","Visual Analytic","3");

INSERT INTO DEGREE_REQUIREMENTS (degreeName,degreeRequirementID,startTerm,endTerm,minGPA,educationLevel) VALUES ("MSCS","5","Fall 2015","Fall 2017","3.5","MS");
INSERT INTO DEGREE_REQUIREMENTS (degreeName,degreeRequirementID,startTerm,endTerm,minGPA,educationLevel) VALUES ("MSIS","6","Fall 2015","Fall2017","3.4","MS");
INSERT INTO DEGREE_REQUIREMENTS (degreeName,degreeRequirementID,startTerm,endTerm,minGPA,educationLevel) VALUES ("MSGIS","7","Fall 2017","Fall 2019","3.8","MS");
INSERT INTO DEGREE_REQUIREMENTS (degreeName,degreeRequirementID,startTerm,endTerm,minGPA,educationLevel) VALUES ("MSDSBA","8","Fall 2016","Fall 2018", "3.6","MS");

INSERT INTO DRTESTSCORE (degreeName,testName,scoreVerbal,scoreQuant,scoreAwa) VALUES ("MSCS","GRE","156","161","3.0");
INSERT INTO DRTESTSCORE (degreeName,testName,scoreVerbal,scoreQuant,scoreAwa) VALUES ("MSIS","GRE","158","164","4.0");
INSERT INTO DRTESTSCORE (degreeName,testName,scoreVerbal,scoreQuant,scoreAwa) VALUES ("MSGIS","GRE","150","160","3.0");
INSERT INTO DRTESTSCORE (degreeName,testName,scoreVerbal,scoreQuant,scoreAwa) VALUES ("MSDSBA","GRE","158","159","4.5");

INSERT INTO RECRUITER (departmentID,userName,recoveryQuestion,recoveryAnswer,pass,email,firstName,middleName,lastName) VALUES ("ITCS","sgall","Who is your favourite person?","My Dad","12345","sgall@uncc.edu","Stephen","Matthew","Gallagher");
INSERT INTO RECRUITER (departmentID,userName,recoveryQuestion,recoveryAnswer,pass,email,firstName,middleName,lastName) VALUES ("ITIS","dribarski","What is your favourite pet?","My Dog","asdfghj","dribarski@uncc.edu","Debbie","Nicole","Ribarski");
INSERT INTO RECRUITER (departmentID,userName,recoveryQuestion,recoveryAnswer,pass,email,firstName,middleName,lastName) VALUES ("GEOG","pkash","Where did you born?","My town","chjgvhk","pkash@uncc.edu","Pouya","","Kashi");
INSERT INTO RECRUITER (departmentID,userName,recoveryQuestion,recoveryAnswer,pass,email,firstName,middleName,lastName) VALUES ("DSBA","abaker3","Where do you live?","My street","hkgvhkc","abaker3@uncc.edu","Anna","Rose","Baker");

INSERT INTO STUDENT (userName,recoveryQuestion,recoveryAnswer,pass,studentStatus,email,firstName,lastName,gpa,lastLogin,numberOfLogins) VALUES ("hemala","What is your favourite sport?","Soccer","habdcjhb","OS","hemala@uncc.edu","Hasan","Hemalaek","3.2","2014-12-24","54");
INSERT INTO STUDENT (userName,recoveryQuestion,recoveryAnswer,pass,studentStatus,email,firstName,lastName,gpa,lastLogin,numberOfLogins) VALUES ("vaide","What is your favourite Movie?","Pulp Fiction","kbvkber","IS","vaide@uncc.edu","Joe","Vaiden","3.0","2015-01-24","89");
INSERT INTO STUDENT (userName,recoveryQuestion,recoveryAnswer,pass,studentStatus,email,firstName,lastName,gpa,lastLogin,numberOfLogins) VALUES ("obama","What is your favourite sport?","Volleyball","sdhbcsh","OS","obama@uncc.edu","Jennifer","Obamask","3.2","2015-02-12","45");
INSERT INTO STUDENT (userName,recoveryQuestion,recoveryAnswer,pass,studentStatus,email,firstName,lastName,gpa,lastLogin,numberOfLogins) VALUES ("jafar","What is your pet's name?","Hiccup","jhdcvj","OS","jafar@uncc.edu","jafar","jafarian","3.9","2015-01-01","523");

-- Student Id is automatic. I used 1,2,3, and 4 for it in below statements.
INSERT INTO INTERESTED_DEGREE (studentID,degreeName) VALUES ("1","MSCS");
INSERT INTO INTERESTED_DEGREE (studentID,degreeName) VALUES ("2","MSIS");
INSERT INTO INTERESTED_DEGREE (studentID,degreeName) VALUES ("3","MSGIS");
INSERT INTO INTERESTED_DEGREE (studentID,degreeName) VALUES ("4","MSDSBA");

INSERT INTO INTERESTED_RESEARCH (studentID,researchAreaName) VALUES ("1","Text Mining");
INSERT INTO INTERESTED_RESEARCH (studentID,researchAreaName) VALUES ("2","Security");
INSERT INTO INTERESTED_RESEARCH (studentID,researchAreaName) VALUES ("3","GIS");
INSERT INTO INTERESTED_RESEARCH (studentID,researchAreaName) VALUES ("4","Big Data");

INSERT INTO ADDRESS (zipCode,city,state,country,street) VALUES ("11092","New York","NY","U.S.A","34,George Clooney Aven.");
INSERT INTO ADDRESS (zipCode,city,state,country,street) VALUES ("28262","Charlotte","NC","U.S.A","9310, Grove Side Ln.");
INSERT INTO ADDRESS (zipCode,city,state,country,street) VALUES ("81393","Denver","CO","U.S.A","76, mary luis Ln.");
INSERT INTO ADDRESS (zipCode,city,state,country,street) VALUES ("24515","Los Angeles","CA","U.S.A","98, Washingto Street, Apt. #87");

INSERT INTO TEST (studentID,testID,testName,testDate,scoreVerbal,scoreQuant,scoreAwa) VALUES ("1","20003012","GRE","2013-09-08","160","165","4.5");
INSERT INTO TEST (studentID,testID,testName,testDate,scoreVerbal,scoreQuant,scoreAwa) VALUES ("2","20003013","GRE","2014-11-19","150","167","3.5");
INSERT INTO TEST (studentID,testID,testName,testDate,scoreVerbal,scoreQuant,scoreAwa) VALUES ("3","20003014","GRE","2013-01-12","144","160","4.0");
INSERT INTO TEST (studentID,testID,testName,testDate,scoreVerbal,scoreQuant,scoreAwa) VALUES ("4","20003015","GRE","2013-04-21","163","163","5.0");

INSERT INTO INTERNAL_STUDENT (studentID,onCampusJob,classStanding,currentCredits,expectedGraduationDate,startTerm) VALUES ("1","RA","!!","24","2015-05-14","Fall 2013");
INSERT INTO INTERNAL_STUDENT (studentID,onCampusJob,classStanding,currentCredits,expectedGraduationDate,startTerm) VALUES ("2","NA","!!","12","2016-05-12","Fall 2014");
INSERT INTO INTERNAL_STUDENT (studentID,onCampusJob,classStanding,currentCredits,expectedGraduationDate,startTerm) VALUES ("3","TA","!!","18","2015-12-23","Spring 2014");
INSERT INTO INTERNAL_STUDENT (studentID,onCampusJob,classStanding,currentCredits,expectedGraduationDate,startTerm) VALUES ("4","TA","!!","24","2015-05-14","Fall 2013");

INSERT INTO EXTERNAL_STUDENT (studentID,jobExperience,jobDescription,extraCurricular) VALUES ("1","NA","NA","Interesting in physics");
INSERT INTO EXTERNAL_STUDENT (studentID,jobExperience,jobDescription,extraCurricular) VALUES ("2","5 years","Manager in a web design company.","motivated in learning");
INSERT INTO EXTERNAL_STUDENT (studentID,jobExperience,jobDescription,extraCurricular) VALUES ("3","3 years","GIS Specialist in ESRI","");
INSERT INTO EXTERNAL_STUDENT (studentID,jobExperience,jobDescription,extraCurricular) VALUES ("4","15 years","Working for BofA.","");

INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (departmentID,professorName,researchAreaName) VALUES ("ITCS","Kalpathi Subramanian","GIS");
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (departmentID,professorName,researchAreaName) VALUES ("ITIS","Wlodek Zadrozny","Text Mining");
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (departmentID,professorName,researchAreaName) VALUES ("GEOG","Ali Naderan","GIS");
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (departmentID,professorName,researchAreaName) VALUES ("DSBA","Kristine Dohner","Security");

INSERT INTO STUDENT_LIVES_ADDRESS (studentID,addressID) VALUES ("1","1");
INSERT INTO STUDENT_LIVES_ADDRESS (studentID,addressID) VALUES ("2","2");
INSERT INTO STUDENT_LIVES_ADDRESS (studentID,addressID) VALUES ("3","3");
INSERT INTO STUDENT_LIVES_ADDRESS (studentID,addressID) VALUES ("4","4");

INSERT INTO RECRUITER_RECRUITS_STUDENT (recruiterID,studentID,recruitStatus) VALUES("1","1","C");
INSERT INTO RECRUITER_RECRUITS_STUDENT (recruiterID,studentID,recruitStatus) VALUES("2","2","C");
INSERT INTO RECRUITER_RECRUITS_STUDENT (recruiterID,studentID,recruitStatus) VALUES("3","3","C");
INSERT INTO RECRUITER_RECRUITS_STUDENT (recruiterID,studentID,recruitStatus) VALUES("4","4","C");

INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (studentID,departmentID) VALUES ("1","ITCS");
INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (studentID,departmentID) VALUES ("2","ITIS");
INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (studentID,departmentID) VALUES ("3","GEOG");
INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (studentID,departmentID) VALUES ("4","DSBA");

INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (studentID,degreeName,recruiterID,reviewStatus,startTerm,applicationStatus,admissionDecision) VALUES ("1","MSCS","1","C","Fall 2013","C","A");
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (studentID,degreeName,recruiterID,reviewStatus,startTerm,applicationStatus,admissionDecision) VALUES ("2","MSIS","2","C","Fall 2014","C","A");
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (studentID,degreeName,recruiterID,reviewStatus,startTerm,applicationStatus,admissionDecision) VALUES ("3","MSGIS","3","C","Spring 2014","C","A");
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (studentID,degreeName,recruiterID,reviewStatus,startTerm,applicationStatus,admissionDecision) VALUES ("4","MSDSBA","4","C","Fall 2013","C","A");

/*Team 2 Insert Statements */
INSERT INTO DEPARTMENT VALUES
	('MDSK','Middle, Secondary...','Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui.'),
	('FARS','Farsi','Aliquam erat volutpat. In congue. Etiam justo.'),
	('ECGR','Electrical and Co...','Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi.'),
	('SPCD','Special Education...','Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.');

INSERT INTO PROFESSOR VALUES
	('Toshinori Iwata','PhD in Computer Engineering','Recording rock covers to video game soundtracks and making video games.'),
	('Sandy Smith','MS in Physics','Putting out Bunsen burner started fires.'),
	('Watson Jones','PhD in Psychology','Watching Jeopardy with his colleagues.'),
	('Adol Christin','BA in Art','Sailing around the world on his ship.');

INSERT INTO RESEARCH VALUES
	('HTC Vive Learning','Learning Lab','Teaching young children about the world we live in using the HTC Vive.'),
	('Reflexes of Multi...','Language Lab','Study of the reflexes of multilingual people versus people who only know one language.'),
	('Brains of HTC Viv...','Psychology Lab','Studying brain activity in users of the HTC Vive.'),
	('Teaching Farsi to...','Language Lab','Showing the effects on llamas while learning the Farsi language.');
	
INSERT INTO CURRENT_RA VALUES
	('HTC Vive Learning','Miroslaw Hewitt'),
	('Reflexes of Multi...','Giuliano De Sauveterre'),
	('Brains of HTC Viv...','Kaarlo Meadows'),
	('Teaching Farsi to...','Dado Bonney');

INSERT INTO DEGREE VALUES
	('ECGR','BAECGR','Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.','9999-03-01 23:59:59','9999-11-15 23:59:59',120,'Fall 1986',1057),
	('ECGR','BSECGR','Phasellus in felis. Donec semper sapien a libero. Nam dui.','9999-03-01 23:59:59','9999-11-15 23:59:59',120,'Fall 1986',1823),
	('ECGR','MSECGR','Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.','9999-03-01 23:59:59',null,30,'Spring 1999',84),
	('ECGR','PhDECGR','Etiam pretium iaculis justo. In hac habitasse platea dictumst. Etiam faucibus cursus urna.',null,'9999-11-15 23:59:59',78,'Fall 2004',17);

INSERT INTO COURSE_CATALOG VALUES
	('BAECGR','Fusce consequat',3),
	('BSECGR','Mauris sit amet eros',3),
	('MSECGR','In hac habitasse',3),
	('BSECGR','Nulla tellus',3);

INSERT INTO DEGREE_REQUIREMENTS VALUES
	('BAECGR',1,'Fall 2015','Spring 2018',2,'UD'),
	('BSECGR',2,'Fall 2015','Spring 2018',2,'UD'),
	('MSECGR',3,'Fall 2015','Spring 2016',3,'MS'),
	('PhDECGR',4,'Fall 2016','Spring 2017',3.5,'HS');

INSERT INTO DRTESTSCORE VALUES
	('BAECGR','SAT',60,50,0),
	('BSECGR','SAT',60,50,0),
	('MSECGR','GRE',75,80,0.4),
	('BSECGR','ACT',50,75,0);

-- TODO: encrypt passwords:
INSERT INTO RECRUITER (userName, recoveryQuestion, recoveryAnswer, pass, email, firstName, middleName, lastName, departmentID) VALUES
	('icardona','What is your pet''s name?','Whiskers','wh1sk3r5','icardona@uncc.edu','Iason','Nikolaus','Cardona','SPCD'),
	('blowell','What is your favorite game?','Tales of Vesperia','br1ll1@ant_ph03niX','blowell@uncc.edu','Baptista','Matyas','Lowell','ECGR'),
	('cduarte2','What was your first vehicle?','Tricycle','5ifu253SgG8*@Q','cduarte2@uncc.edu','Chimwemwe','Teivel','Duarte','FARS'),
	('stillens','What is your favorite number?','-87.245','b0b','stillens@uncc.edu','Straton','Winoc','Tillens','ECGR');
	
-- TODO: encrypt passwords:
INSERT INTO STUDENT (userName, recoveryQuestion, recoveryAnswer, pass, studentStatus, email, firstName, lastName, gpa, lastLogin, numberOfLogins) VALUES
	('mbuffone','What is your mother''s maiden name?','Simeonov','i6iTaEqfrW','OS','mbuffone@uncc.edu','Mohana','Buffone',3.42,'2014-12-24 08:37:42',12),
	('cquattrocchi','What was your first album?','Gorillaz: Demon Days','9IXdJmDKxZs','IS','cquattrocchi@uncc.edu','Carme','Quattrocchi',2.89,'2014-05-15 18:27:12',2896),
	('rmitchell','What is the name of your pet?','Cleo','C2SOgHSzQl5o','IS','rmitchell@uncc.edu','Rona','Mitchell',3.16,'2015-03-02 23:16:33',876),
	('jcapitani','What was the name of your elementary school?','Mercier Elementary','fe6ultqig','IS','jcapitani@uncc.edu','Judicael','Capitani',3.98,'2015-07-28 12:16:54',1754);

INSERT INTO INTERESTED_DEGREE VALUES
	(5,'BSPSYC'),
	(6,'MAPSYC'),
	(7,'PhDHealthPSYC'),
	(8,'BAPSYC');

INSERT INTO INTERESTED_RESEARCH VALUES
	(5,'Teaching Farsi to...'),
	(4,'Teaching Farsi to...'),
	(7,'Reflexes of Multi...'),
	(8,'HTC Vive Learning');

INSERT INTO ADDRESS (zipCode, city, state, country, street) VALUES
	('25721','Huntington','West Virginia','United States','59 Oakridge Point'),
	('02905','Providence','Rhode Island','United States','66 Green Ridge Circle'),
	('80235','Denver','Colorado','United States','45614 Erie Park'),
	('18763','Wilkes Barre','Pennsylvania','United States','4378 Michigan Lane');
	
INSERT INTO TEST VALUES
	(5, 1, 'SAT', '2014-10-07', 0.81, 0.37, 0.2),
	(8, 2, 'TFL', '2014-06-02', 0.63, 0, 0.04),
	(6, 3, 'ACT', '2014-11-03', 0.83, 0.56, 0.59),
	(7, 4, 'TFL', '2015-01-05', 0.87, 0.92, 0.94);
	
INSERT INTO INTERNAL_STUDENT VALUES
	(5, null, 'Bad', 1, '2017-12-02', 'Fall 2014'),
	(8, null, 'Bad', 115, '2017-05-01', 'Spring 2015');

INSERT INTO EXTERNAL_STUDENT VALUES
	(6, 'id nulla', 'In hac habitasse platea dictumst.', 'urna pretium'),
	(7, 'vel pede morbi porttitor', 'Pellentesque at nulla.', 'lectus');
	
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH VALUES
	('SPCD', 'Toshinori Iwata', 'Brains of HTC Viv...'),
	('MDSK', 'Sandy Smith', 'HTC Vive Learning'),
	('FARS', 'Watson Jones', 'Teaching Farsi to...'),
	('FARS', 'Adol Christin', 'Reflexes of Multi...');
	
INSERT INTO STUDENT_LIVES_ADDRESS VALUES
	(5, 7),
	(6, 6),
	(7, 8),
	(8, 5);
	
INSERT INTO RECRUITER_RECRUITS_STUDENT VALUES
	(5,8,'I'),
	(6,5,'C'),
	(7,6,'C'),
	(8,7,'C');

INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT VALUES
	(6,'SPCD'),
	(5,'ECGR'),
	(6,'MDSK'),
	(7,'MDSK');
	
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER VALUES
	(5,'BAECGR',6,'C','Fall 2013','I','N'),
	(5,'BSECGR',8,'C','Fall 2013','C','A'),
	(8,'BSECGR',6,'C','Fall 2015','C','D'),
	(8,'MSECGR',6,'I','Fall 2018','I','N');
    
/*Team 3 Insert Statements*/
INSERT INTO DEPARTMENT VALUES ( "ENGL", "English", "The English department specializes in the written and spoken fields of the English languages." );
INSERT INTO DEPARTMENT VALUES ( "EDUC", "Education", "The education department focuses on training the teachers which will provide training to the next generation." );

INSERT INTO PROFESSOR VALUES ( "John Jacobson", "Dr. in English from Brown University", "Specializes in the study of Shakespearean English" );
INSERT INTO PROFESSOR VALUES ( "Elizabeth Wright", "Dr. in Education Philosophy from University of Phoenix","Thirty years of work in the CMS Education System and 10 books on education" );

INSERT INTO RESEARCH VALUES ( "Shakespearean Lit","Fretwell 201","Comparison of original manuscripts to derive the cultural, historical, and literary background of Shakespeare's day" );
INSERT INTO RESEARCH VALUES ( "Elementary Ed","King 112","Studying the development of the elementary student's mind in regards to social and psychological growth." );

INSERT INTO CURRENT_RA VALUES ( "Shakespearean Lit","Peter Edwards" );
INSERT INTO CURRENT_RA VALUES ( "Elementary Ed","Andrew White" );

INSERT INTO DEGREE VALUES ( "ENGL","BAEN","Bachelors of Arts in English",10/15/2015,3/15/2015,120,"Fall 2011",2000 );
INSERT INTO DEGREE VALUES ( "EDUC","BAED","Bachelors of Arts in Education",10/15/2015,3/15/2015,120,"Fall 2012",2000 );

INSERT INTO COURSE_CATALOG VALUES ( "BAEN", "B.A. in English",120 );
INSERT INTO COURSE_CATALOG VALUES ( "BAED", "B.A. in Education",120 );

INSERT INTO DEGREE_REQUIREMENTS VALUES ( "BAEN",1,"Fall 2011","Spring 2015",3.0,"HS" );
INSERT INTO DEGREE_REQUIREMENTS VALUES ( "BAED",2,"Fall 2011","Spring 2015",3.0,"HS" );

INSERT INTO DRTESTSCORE VALUES ( "BAEN","SAT",560,500,500 );
INSERT INTO DRTESTSCORE VALUES ( "BAED","SAT",540,500,500 );

INSERT INTO RECRUITER VALUES ( 10001,"JAlwerdt","What is the name of your first boss?","Kevin","pass01","jalwerdt@uncc.edu","Jonathan","Felix","Alwerdt","ENGL" );
INSERT INTO RECRUITER VALUES ( 10002,"MKevlin","What is the first car you owned?","Focus","Password123","mkevlin@uncc.edu","Michelle","Diane","Kevlin","EDUC" );

INSERT INTO STUDENT VALUES ( 400300001,"KHart4","What is your favorite flower?","Sunflower","administrator1","IS","khart4@uncc.edu","Kevin","Hart",3.7,2/5/2015,2104 );
INSERT INTO STUDENT VALUES ( 400300002,"EJohns9","What is the name of your street?","Poppy Way","password71","IS","ejohns4@uncc.edu","Erica","Johnson",3.8,2/19/2015,1283 );

INSERT INTO INTERESTED_DEGREE VALUES  ( 400300001,"BAEN" );
INSERT INTO INTERESTED_DEGREE VALUES  ( 400300002,"BAED" );

INSERT INTO INTERESTED_RESEARCH VALUES ( 400300001, "Shakespearean Lit" );
INSERT INTO INTERESTED_RESEARCH VALUES ( 400300002, "Elementary Ed" );

INSERT INTO ADDRESS VALUES ( 3007001, 28027, "Charlotte", "NC", "USA", "3974 Longbriar Lane" );
INSERT INTO ADDRESS VALUES ( 3007002, 28279, "Charlotte", "NC", "USA", "1383 Cedar Lane" );

INSERT INTO TEST VALUES ( 400300001, 20003010, "SAT",9/10/2012,680,540,560 );
INSERT INTO TEST VALUES ( 400300002, 20003011, "SAT",5/19/2013,610,570,520 );

INSERT INTO INTERNAL_STUDENT VALUES ( 400300001, "RA","Good",115,5/5/2015,"Fall 2011" );
INSERT INTO INTERNAL_STUDENT VALUES ( 400300002, "TA","Good",75,5/5/2016,"Fall 2012" );

INSERT INTO EXTERNAL_STUDENT VALUES ( 400300001, "Research Writer, Secretary, Auditor, Journalist","Held many different positions requiring interactive literary skills, including journalist and research paper writer.","Teaching at CMS" );
INSERT INTO EXTERNAL_STUDENT VALUES ( 400300002, "Teaching in CMS for 30 years","Taught Elementary School (all subjects) for 30 years at Elizabeth Traditional Elementary School.","Research Project" );

INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH VALUES ( "ENGL", "John Jacobson","Shakespearean Lit" );
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH VALUES ( "EDUC", "Elizabeth Wright","Elementary Ed" );

INSERT INTO STUDENT_LIVES_ADDRESS VALUES ( 400300001, 3007001 );
INSERT INTO STUDENT_LIVES_ADDRESS VALUES ( 400300002, 3007002 );

INSERT INTO RECRUITER_RECRUITS_STUDENT VALUES ( 10001, 400300001, "C" );
INSERT INTO RECRUITER_RECRUITS_STUDENT VALUES ( 10002, 400300002, "C" );

INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT VALUES ( 400300001, "ENGL" );
INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT VALUES ( 400300002, "EDUC" );

INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER VALUES ( 400300001, "BAEN", 10001, "C", "Fall 2011", "C", "A" );
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER VALUES ( 400300002, "BAED", 10002, "C", "Fall 2012", "C", "A" );

/*Team 4 Insert Satements*/
INSERT INTO DEPARTMENT (departmentID,departmentName,departmentDescription) VALUES 
('MATH','Mathematics','Department of Mathematics'),
('BIO','BioInformatics','Department of BioInformatics'),
('GEOL','Geology','The department of Geology is compromised of physical, natural and social scientists.'),
('PSYC','Psychology','The department of Psychology works to advance the science of psychology.');

INSERT INTO PROFESSOR (professorName,professorDegreeDetail,professorInterests) VALUES 
('Alan Von','Phd Mathematics','Statistical Data'),
('Payal Jain','Phd BioInformatics','Diversification and Macroevolution'),
('Jing Lee','Ph.D. MS','ethnographic methods'),
('Andrew Gilbert','Ph.D. MS','Psychological Developments');

INSERT INTO RESEARCH (researchAreaName,researchLab,researchDescription) VALUES
('Mathematics','MATH Lab','Precalculus Mathematics research with Functions and graphs, linear and quadratic functions'),
('Biophysics','Bioinformatics Lab','computational biophysics attempts to develop theoretical models that capture the essential physics'),
('Effectiveness','Psych Lab','Taking into account the ratio of the effectiveness of a website with respect to the amount of publicity given.'),
('Planning','Geology Lab','The target population is the Deaf and Hard of Hearing to realize the importance of ingretiating the hearing impaired into the planning process.');

INSERT INTO CURRENT_RA (researchAreaName,researchAssistantName) VALUES
('Mathematics','Mary John'),
('Biophysics','Anik T'),
('Effectiveness','David Xiao'),
('Planning','Yash Patel');

INSERT INTO DEGREE (departmentID,degreeName,degreeDescription,fallDeadline,springDeadline,credits,startedSemester,totalIntake) VALUES 
('MATH','MSMF','Master of Science in Mathematical Finance','2015-03-01','2015-08-15',10,'Fall 2000',150),
('BIO','MSBI','Master of Science in Bioinformatics','2015-03-15','2015-08-30',12,'Fall 2010',80),
('GEOL','MSGeo','The M.S. in Geography at UNC Charlotte emphasizes the application of geo and theory to problem solving in contemporary society.','2016-03-20','2016-09-30',36,'SPRING 2010',40),
('PSYC','MSPsy','The Community Psychology Training Program is comprised of 3 separate but related components for students at different levels.','2016-03-30','2016-09-30',30,'FALL 2001',50);

INSERT INTO COURSE_CATALOG (degreeName,courseName,creditValue) VALUES 
('MSMF','Master of Science Math',33),
('MSBI','MS Bioinformatics',30),
('MSGeo','Masters Geology',30),
('MSPsy','Masters Psych',3);

INSERT INTO DEGREE_REQUIREMENTS (degreeName,degreeRequirementID,startTerm,endTerm,minGPA,educationLevel) VALUES 
('MSMF',3,'Fall 2012','Spring 2015',3.2,'MS'),
('MSBI',4,'Fall 2012','Spring 2015',3.2,'MS'),
('MSGeo',10,'Fall 2015','Spring 2017',3.0,'UG'),
('MSPsy',10,'Fall 2015','Spring 2017',2.5,'UG');

INSERT INTO DRTESTSCORE (degreeName,testName,scoreVerbal,scoreQuant,scoreAwa) VALUES 
('MSMF','GRE',145,155,3),
('MSBI','TOE',98,0,3.5),
('MSGeo','GRE',150,150,3.5),
('MSPsy','GRE',150,150,3.5);

INSERT INTO RECRUITER (recruiterID,departmentID,userName,recoveryQuestion,recoveryAnswer,pass,email,firstName,middleName,lastName) VALUES
(10007,'MATH','gracec','What is your favorite color?','Red','Pass489','grace@unp.edu','Grace','S','Chen'),
(10008,'BIO','Xingp','What is your favorite color?','Blue','Pass123','xingp@unp.edu','Xing','V','Peng'),
(10009,'GEOL','REC18','What is your pets name?','whiskey','rec192021','rec19@gmail.com','Dave','Anj','Kepler'),
(10010,'PSYC','REC19','What is your fathers name?','Albert','rec181920','rec18@gmail.com','Andrew','Albert','Dumbledore');


INSERT INTO STUDENT (studentID,userName,recoveryQuestion,recoveryAnswer,pass,studentStatus,email,firstName,lastName,gpa,lastLogin,numberOfLogins) VALUES
(400300007,'rekhas','Maiden Name of your Mother?','Anna','Pass753','IN','rekha@hotmail.com','Rekha','Seth',3.2,'2014-02-03 16:15:15',4),
(400300008,'shikhas','What is your favourite color?','green','Logg7853','IN','shikha@yahoo.com','Dev','Patel',3.5,'2015-02-05 20:00:00',5),
(400300011,'seanr','What is your favourite color?','yellow','QWE455','IS','sron@gmail.com','Sean','Ron',3.0,'2015-02-05 15:00:00',2),
(400300012,'danb','What is your favourite color?','pink','QW5565','IS','dbell@outlook.com','Dan','bell',3.2,'2015-02-12 15:20:00',7),
(400300009,'fgerar109','What is your favourite color?','blue','Gave3_45','IS','frankger109@gmail.com','Frank','Gerard',3.0,'2015-03-03 23:15:15',10),
(400300010,'dpate110','What is your favourite color?','green','Rain_45','IN','dpate110@gmail.com','Dev','Patel',3.0,'2015-02-03 23:15:15',6);

INSERT INTO INTERESTED_DEGREE(studentID,degreeName) VALUES 
(400300007,'MSMF'),
(400300008,'MSBI'),
(400300009,'MSGeo'),
(400300010,'MSPsy');

INSERT INTO INTERESTED_RESEARCH (studentID,researchAreaName) VALUES
(400300007,'MSMF'),
(400300008,'MSBI'),
(400300009,'MSGeo'),
(400300010,'MSPsy');

INSERT INTO ADDRESS (addressID,zipCode,city,state,country,street) VALUES 
(3007007,28262,'Charlotte','NC','USA','Grove lane'),
(3007008,28262,'Railegh','NC','USA','Grove Crest Lane'),
(3007009,37020,'Tempe','NC','USA','McBerry Lane'),
(3007010,37032,'Ahmedabad','GUJ','India','Bodakdev');

INSERT INTO TEST (studentID,testID,testName,testDate,scoreVerbal,scoreQuant,scoreAwa) VALUES
(400300007,20003022,'GRE','2014-01-06','150','159',3.2),
(400300008,20003023,'GRE','2014-06-06','148','160',3.3),
(400300009,20003020,'GRE','2014-06-06','153','159',3.6),
(400300010,20003021,'GRE','2014-10-06','160','160',3.6);

INSERT INTO INTERNAL_STUDENT (studentID,onCampusJob,classStanding,currentCredits,expectedGraduationDate,startTerm) VALUES
(400300011,'CW','Fifth',12,'2016-05-15','SPRING 2015'),
(400300012,'RA','Second',16,'2016-06-06','Fall 2015');

INSERT INTO EXTERNAL_STUDENT (studentID,jobExperience,jobDescription,extraCurricular) VALUES 
(400300007,'2 years','Software Tester','Singer'),
(400300008,'3.5 years','Software Engineer','Acting'),
(400300009,'None','None','Ethical Hacking'),
(400300010,'Three years','Sr.Software Engineer','Application Dev');


INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (departmentID,professorName,researchAreaName) VALUES 
('MATH','Alan Von','Mathematics'),
('BIO','Payal Jain','Biophysics'),
('GEOL','Jing Lee','Effectiveness'),
('PSYC','Andrew Gilbert','Planning');

INSERT INTO STUDENT_LIVES_ADDRESS (studentID,addressID) VALUES
(400300007,3007007),
(400300008,3007008),
(400300009,3007009),
(400300010,3007010);

INSERT INTO RECRUITER_RECRUITS_STUDENT (recruiterID,studentID,recruitStatus) VALUES
(10007,400300007,'C'),
(10008,400300008,'I'),
(10009,400300009,'C'),
(10010,400300010,'I');

INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (studentID,departmentID) VALUES
(400300007,'MATH'),
(400300008,'BIO'),
(400300009,'GEOL'),
(400300010,'PSYC');
 
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (studentID,degreeName,recruiterID,reviewStatus,startTerm,applicationStatus,admissionDecision) VALUES 
(400300007,'MSMF',10007,'C','Spring15','C','A'),
(400300008,'MSBI',10008,'C','Spring15','I','D'),
(400300009,'MSPsy',10009,'C','Spring14','C','A'),
(400300010,'MSGeo',10010,'C','Spring15','C','A');

/*Team 5 Insert Statements */

INSERT INTO DEPARTMENT (`departmentID`, `departmentName`, `departmentDescription`) VALUES ('ITSE', 'Information Technology Software Engineering', 'The Information Technology Software Engineering is focused on sofware engenerring and system programming related stuff');
INSERT INTO DEPARTMENT (`departmentID`, `departmentName`, `departmentDescription`) VALUES ('ITSS', 'Information Technology Security Systems', 'The Information Technology Security Systems Department deals with Security in Software as well as more industry related issues');

INSERT INTO PROFESSOR (`professorName`, `professorDegreeDetail`, `professorInterests`) VALUES ('Ali Sever', 'Dr in Programming language From UNCC', 'Programming');
INSERT INTO PROFESSOR (`professorName`, `professorDegreeDetail`, `professorInterests`) VALUES ('Devan Ahmed', 'Dr in Networking from NCSU', 'Networking');

INSERT INTO RESEARCH (`researchAreaName`, `researchLab`, `researchDescription`) VALUES ('Image Net', 'Woodward 212', 'image database organized according to the WordNet hierarchy');
INSERT INTO RESEARCH (`researchAreaName`, `researchLab`, `researchDescription`) VALUES ('Access Networks', 'Woodward 311', 'OpenWRT-based platform for performing measurements of ISP performance');

INSERT INTO CURRENT_RA (`researchAreaName`, `researchAssistantName`) VALUES ('Image Net', 'Sumit Kumar');
INSERT INTO CURRENT_RA (`researchAreaName`, `researchAssistantName`) VALUES ('Access Networks', 'Jack Willam');

INSERT INTO DEGREE (`departmentID`, `degreeName`, `degreeDescription`, `fallDeadline`, `springDeadline`, `credits`, `startedSemester`, `totalIntake`) VALUES ('ITSE','MSSE', 'Master of science in Software Engineering', '2015-12-12 11:55:55', '2015-03-03 11:55:55', '30', 'Fall 2012', '2');
INSERT INTO DEGREE (`departmentID`, `degreeName`, `degreeDescription`, `fallDeadline`, `springDeadline`, `credits`, `startedSemester`, `totalIntake`) VALUES ('ITSS', 'MSSS', 'Master of science in Security Systems', '2015-12-12 11:55:55', '2015-03-03 11:55:55', '30', 'Springs 2011', '2');

INSERT INTO COURSE_CATALOG (`degreeName`, `courseName`, `creditValue`) VALUES ('MSSE', 'SSDI', '3');
INSERT INTO COURSE_CATALOG(`degreeName`, `courseName`, `creditValue`) VALUES ('MSSS', 'SPL', '3');

INSERT INTO DEGREE_REQUIREMENTS (`degreeName`, `degreeRequirementID`, `startTerm`, `endTerm`, `minGPA`, `educationLevel`) VALUES ('MSSE', '11', 'Fall 2014', 'Spring 2016', '3.0', 'UD');
INSERT INTO DEGREE_REQUIREMENTS (`degreeName`, `degreeRequirementID`, `startTerm`, `endTerm`, `minGPA`, `educationLevel`) VALUES ('MSSS', '12', 'Spring 2014', 'Fall 2015', '3.0', 'UD');

INSERT INTO DRTESTSCORE (`degreeName`, `testName`, `scoreVerbal`, `scoreQuant`, `scoreAwa`) VALUES ('MSSE', 'GRE', '148', '162', '3.0');
INSERT INTO DRTESTSCORE (`degreeName`, `testName`, `scoreVerbal`, `scoreQuant`, `scoreAwa`) VALUES ('MSSS', 'GRE', '150', '160', '3.0');

INSERT INTO RECRUITER (`recruiterID`, `userName`, `recoveryQuestion`, `recoveryAnswer`, `pass`, `email`, `firstName`, `middleName`, `lastName`, `departmentID`) VALUES ('11001', 'tomw', 'What is place of Birth?', 'Texas', 'password1', 'tom@uncc.edu', 'Tom', 'M', 'White', 'ITSS');
INSERT INTO RECRUITER (`recruiterID`, `userName`, `recoveryQuestion`, `recoveryAnswer`, `pass`, `email`, `firstName`, `middleName`, `lastName`, `departmentID`) VALUES ('11002', 'jackb', 'What is place of birth?', 'Charlotte', 'password2', 'jack@uncc.edu', 'Jack', 'W', 'Bauer', 'ITSE');

INSERT INTO STUDENT (`studentID`, `userName`, `recoveryQuestion`, `recoveryAnswer`, `pass`, `studentStatus`, `email`, `firstName`, `lastName`, `gpa`, `lastLogin`, `numberOfLogins`) VALUES ('800800201', 'upalar', 'Name of brand of your car?', 'Toyota', 'qwerty123', 'IN', 'rohitu@uncc.edu', 'Rohit', 'Upalaptthi', '3.0', '2015-02-10 10:15:00', '3');
INSERT INTO STUDENT (`studentID`, `userName`, `recoveryQuestion`, `recoveryAnswer`, `pass`, `studentStatus`, `email`, `firstName`, `lastName`, `gpa`, `lastLogin`, `numberOfLogins`) VALUES ('800800202', 'kiriy', 'Name of your favourite color', 'Blue', '1234qwer', 'IN', 'yatink@uncc.edu', 'Yatin', 'Kiri', '3.0', '2015-01-10 10:10:00', '4');

INSERT INTO INTERESTED_DEGREE (`studentID`, `degreeName`) VALUES ('800800201', 'MSSE');
INSERT INTO INTERESTED_DEGREE (`studentID`, `degreeName`) VALUES ('800800202', 'MSSS');

INSERT INTO INTERESTED_RESEARCH (`studentID`, `researchAreaName`) VALUES ('800800201', 'Image Net');
INSERT INTO INTERESTED_RESEARCH (`studentID`, `researchAreaName`) VALUES ('800800202', 'Access Networks');

INSERT INTO ADDRESS (`addressID`, `zipCode`, `city`, `state`, `country`, `street`) VALUES ('3700200', '28262', 'Charlotte', 'NC', 'USA', '11018,Graduate Lane');
INSERT INTO ADDRESS (`addressID`, `zipCode`, `city`, `state`, `country`, `street`) VALUES ('3700300', '28211', 'Charlotte', 'NC', 'USA', '10001, Graduate Lane');

INSERT INTO TEST (`studentID`, `testID`, `testName`, `testDate`, `scoreVerbal`, `scoreQuant`, `scoreAwa`) VALUES ('800800201', '12001', 'GRE', '2014-10-10', '148', '160', '3.0');
INSERT INTO TEST (`studentID`, `testID`, `testName`, `testDate`, `scoreVerbal`, `scoreQuant`, `scoreAwa`) VALUES ('800800202', '14001', 'GRE', '2013-09-09', '147', '162', '3.0');

INSERT INTO INTERNAL_STUDENT (`studentID`, `onCampusJob`, `classStanding`, `currentCredits`, `expectedGraduationDate`, `startTerm`) VALUES ('800800201', 'TA', 'GOOD', '18', '2015-12-12', 'Spring 2014');
INSERT INTO INTERNAL_STUDENT (`studentID`, `onCampusJob`, `classStanding`, `currentCredits`, `expectedGraduationDate`, `startTerm`) VALUES ('800800202', 'RA', 'Good', '3', '2015-04-04', 'Fall 2014');

INSERT INTO EXTERNAL_STUDENT (`studentID`, `jobExperience`, `jobDescription`, `extraCurricular`) VALUES ('800800201', 'Support Engineer', 'Support telecom Servers having 3G, LTE', 'Tennis');
INSERT INTO EXTERNAL_STUDENT (`studentID`, `jobExperience`, `jobDescription`, `extraCurricular`) VALUES ('800800202', 'Software Developer', 'Developed Web apps used in real world', 'Music');

INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (`departmentID`, `professorName`, `researchAreaName`) VALUES ('ITSE', 'Ali Sever', 'Image Net');
INSERT INTO DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH (`departmentID`, `professorName`, `researchAreaName`) VALUES ('ITSS', 'Devan Ahmed', 'Access Networks');

INSERT INTO STUDENT_LIVES_ADDRESS (`studentID`, `addressID`) VALUES ('800800201', '3700200');
INSERT INTO STUDENT_LIVES_ADDRESS (`studentID`, `addressID`) VALUES ('800800202', '3700300');

INSERT INTO RECRUITER_RECRUITS_STUDENT (`recruiterID`, `studentID`, `recruitStatus`) VALUES ('11001', '800800201', 'C');
INSERT INTO RECRUITER_RECRUITS_STUDENT (`recruiterID`, `studentID`, `recruitStatus`) VALUES ('11002', '800800202', 'C');

INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (`studentID`, `departmentID`) VALUES ('800800201', 'ITSE');
INSERT INTO STUDENT_SEARCHFOR_DEPARTMENT (`studentID`, `departmentID`) VALUES ('800800202', 'ITSS');

INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (`studentID`, `degreeName`, `recruiterID`, `reviewStatus`, `startTerm`, `applicationStatus`, `admissionDecision`) VALUES ('800800201', 'MSSS', '11001', 'C', 'Fall 2014', 'C', 'A');
INSERT INTO STUDENT_APPLIES_DEGREE_RECRUITER (`studentID`, `degreeName`, `recruiterID`, `reviewStatus`, `startTerm`, `applicationStatus`, `admissionDecision`) VALUES ('800800202', 'MSSE', '11002', 'C', 'Fall 2014', 'C', 'A');


/* Busines Queries */

/*Team 1 Queries B1, B2*/

-- Busines Query 1

#1) Student can create an account for login and logout.
INSERT INTO STUDENT (`studentID`, `userName`, `recoveryQuestion`, `recoveryAnswer`, `pass`, `studentStatus`, `email`, `firstName`, `lastName`, `gpa`, `lastLogin`, `numberOfLogins`) VALUES ('800800221', 'upalar', 'Name of brand of your car?', 'Toyota', 'qwerty123', 'IN', 'rohitu@uncc.edu', 'Rohit', 'Upalaptthi', '3.0', '2015-02-10 10:15:00', '3');

/*
Output:

Query OK, 1 row affected (0.01 sec)
*/

-- Busines Query 2
#2)    Student can recover their account access by answering the recovery question.
SELECT recoveryQuestion FROM STUDENT WHERE studentID=800800221;

/*
Output:

+----------------------------+
| recoveryQuestion           |
+----------------------------+
| Name of brand of your car? |
+----------------------------+
1 row in set (0.01 sec)

mysql> UPDATE STUDENT SET pass="newpassword" WHERE studentID=800800221 AND recoveryAnswer='Toyota';
Query OK, 1 row affected (0.00 sec)
Rows matched: 1  Changed: 1  Warnings: 0
*/

UPDATE STUDENT SET pass="newpassword" WHERE studentID=800800221 AND recoveryAnswer='Toyota';

/*
Output:

Query OK, 1 row affected (0.00 sec)
Rows matched: 1  Changed: 1  Warnings: 0
*/


/*Team 2 Queries B3, B4*/
-- Busines Query 3
/*
	Business Function 3
	Student can update their profile to provide pertinent information about their academic pursuits.
	-------------------
	
	(Adding interested degree)
	
	Parameterized form:
	
		INSERT INTO INTERESTED_DEGREE VALUES
			(?, ?);
			
	Where the first parameter is the current student's id and the second parameter is the degree
	name.
	
	-------------------
	
	(Deleting interested degree)
	
	Parameterized form:
		
		DELETE FROM INTERESTED_DEGREE
			WHERE studentId = ?
			AND degreeName = ?;
			
	Where the first parameter is the current student's id and the second parameter is the degree
	name.
	
	-------------------
	
	(Adding interested research)
	
	Parameterized form:
	
		INSERT INTO INTERESTED_RESEARCH VALUES
			(?, ?);
			
	Where the first parameter is the current student's id and the second parameter is the research area
	name.
	
	-------------------
	
	(Deleting interested research)
	
	Parameterized form:
		
		DELETE FROM INTERESTED_RESEARCH
			WHERE studentId = ?
			AND researchAreaName = ?;
			
	Where the first parameter is the current student's id and the second parameter is the research area
	name.
	
	-------------------
	
	Examples:
*/

-- (Adding interested degree)
INSERT INTO INTERESTED_DEGREE VALUES
	(2, 'MSECGR');

/*
Output:

Query OK, 1 row affected (0.01 sec)

*/


-- (Deleting interested degree)
DELETE FROM INTERESTED_DEGREE
	WHERE studentId = 2
	AND degreeName = 'MSECGR';

/*
Output:

Query OK, 1 row affected (0.01 sec)
*/

-- (Adding interested research)
INSERT INTO INTERESTED_RESEARCH VALUES
	(3, 'HTC Vive Learning');

/*
Output:

Query OK, 1 row affected (0.01 sec)
*/

-- (Deleting interested research)
DELETE FROM INTERESTED_RESEARCH
	WHERE studentId = 3
	AND researchAreaName = 'HTC Vive Learning';

/*
Output:

Query OK, 1 row affected (0.01 sec)
*/

-- Business Query 4

/*
	Business Function 4
	Students can query research information under various professors.
	
	-------------------
	
	Parameterized form:
	
		SELECT researchAreaName, researchLab, researchDescription
			FROM RESEARCH NATURAL JOIN DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH
			WHERE professorName = ?;
			
	Where the parameter is the professor's name.
	
	-------------------
	
	Example:
*/

SELECT researchAreaName, researchLab, researchDescription
	FROM RESEARCH NATURAL JOIN DEPARTMENT_EMPLOYS_PROFESSOR_RESEARCH
	WHERE professorName = 'Sandy Smith';

/*
Output:

+-------------------+--------------+------------------------------------------------------------------------+
| researchAreaName  | researchLab  | researchDescription                                                    |
+-------------------+--------------+------------------------------------------------------------------------+
| HTC Vive Learning | Learning Lab | Teaching young children about the world we live in using the HTC Vive. |
+-------------------+--------------+------------------------------------------------------------------------+
1 row in set (0.00 sec)
*/

/*Team 3 Queries B5, B6*/

/*
	Business Function 5
	Recruiter can review the student application by checking the application status and change the admission status.
	-------------------
	
	(Checking the application status)
	
	Parameterized form:
	
		SELECT degreeName, reviewStatus, startTerm, applicationStatus, admissionDecision
			FROM STUDENT_APPLIES_DEGREE_RECRUITER
			WHERE studentId = ?
			AND recruiterId = ?;
			
	Where the studentId parameter would be the id of the student whose application is being looked at and the
	recruiterId parameter is the id of the current recruiter.
	
	-------------------
	
	(Changing the admission status)
	
	Parameterized form:
	
		UPDATE STUDENT_APPLIES_DEGREE_RECRUITER
			SET reviewStatus = 'C', admissionDecision = ?
			WHERE studentId = ?
			AND recruiterId = ?;
	
	Where the admission decision parameter is the decision of the application and both id parameters are the same
	as checking the application status.
	
	-------------------
	
	Examples:
*/

-- (Checking the application status)

SELECT degreeName, reviewStatus, startTerm, applicationStatus, admissionDecision
	FROM STUDENT_APPLIES_DEGREE_RECRUITER
	WHERE studentID = 8 AND recruiterID = 6;

/*
Output:

+------------+--------------+-----------+-------------------+-------------------+
| degreeName | reviewStatus | startTerm | applicationStatus | admissionDecision |
+------------+--------------+-----------+-------------------+-------------------+
| BSECGR     | C            | Fall 2015 | C                 | D                 |
| MSECGR     | I            | Fall 2018 | I                 | N                 |
+------------+--------------+-----------+-------------------+-------------------+
2 rows in set (0.00 sec)

*/


-- (Changing the admission status)
UPDATE STUDENT_APPLIES_DEGREE_RECRUITER
	SET reviewStatus = 'C', admissionDecision = 'D'
	WHERE studentId = 8
	AND recruiterId = 6;

/*
Output:

Query OK, 1 row affected (0.01 sec)
Rows matched: 2  Changed: 1  Warnings: 0
*/

-- (Checking the application status) again to see the update
SELECT degreeName, reviewStatus, startTerm, applicationStatus, admissionDecision
	FROM STUDENT_APPLIES_DEGREE_RECRUITER
	WHERE studentId = 8
	AND recruiterId = 6;

/*
Output:

+------------+--------------+-----------+-------------------+-------------------+
| degreeName | reviewStatus | startTerm | applicationStatus | admissionDecision |
+------------+--------------+-----------+-------------------+-------------------+
| BSECGR     | C            | Fall 2015 | C                 | D                 |
| MSECGR     | C            | Fall 2018 | I                 | D                 |
+------------+--------------+-----------+-------------------+-------------------+
2 rows in set (0.00 sec)
*/

/*
	Business Function 6
	Recruiter can search for potential prospective students based on the geographic location.
	
	-------------------
	
	Parameterized form:
	
		SELECT userName, studentStatus, email, firstName, lastName, lastLogin, jobExperience, jobDescription, extraCurricular
			FROM STUDENT NATURAL JOIN EXTERNAL_STUDENT NATURAL JOIN STUDENT_LIVES_ADDRESS NATURAL JOIN ADDRESS
			WHERE city = ?
			AND country = ?;
	
	Where the first parameter is the name of the city and the second is the name of the country.
	
	-------------------
	
	Example:
*/


SELECT userName, studentStatus, email, firstName, lastName, lastLogin, jobExperience, jobDescription, extraCurricular
	FROM STUDENT NATURAL JOIN EXTERNAL_STUDENT NATURAL JOIN STUDENT_LIVES_ADDRESS NATURAL JOIN ADDRESS
	WHERE city = 'Providence'
	AND country = 'United States';

/*
Output:

+--------------+---------------+-----------------------+-----------+-------------+---------------------+---------------+-----------------------------------+-----------------+
| userName     | studentStatus | email                 | firstName | lastName    | lastLogin           | jobExperience | jobDescription                    | extraCurricular |
+--------------+---------------+-----------------------+-----------+-------------+---------------------+---------------+-----------------------------------+-----------------+
| cquattrocchi | IS            | cquattrocchi@uncc.edu | Carme     | Quattrocchi | 2014-05-15 18:27:12 | id nulla      | In hac habitasse platea dictumst. | urna pretium    |
+--------------+---------------+-----------------------+-----------+-------------+---------------------+---------------+-----------------------------------+-----------------+
1 row in set (0.00 sec)
*/

/*Team 4 Queries B7, B8*/

-- Busines Query 7

/* Search Students based on Interested Academic Degree*/
SELECT S.studentID,studentStatus,email,firstName,lastName,gpa,degreeName FROM pinnacle.STUDENT S,Interested_Degree
WHERE S.studentID= Interested_Degree.studentID 
order by S.studentID;

/*
Output:

+-----------+---------------+-----------------------+-----------+-------------+------+---------------+
| studentID | studentStatus | email                 | firstName | lastName    | gpa  | degreeName    |
+-----------+---------------+-----------------------+-----------+-------------+------+---------------+
|         1 | OS            | hemala@uncc.edu       | Hasan     | Hemalaek    | 3.20 | MSCS          |
|         2 | IS            | vaide@uncc.edu        | Joe       | Vaiden      | 3.00 | MSIS          |
|         3 | OS            | obama@uncc.edu        | Jennifer  | Obamask     | 3.20 | MSGIS         |
|         4 | OS            | jafar@uncc.edu        | jafar     | jafarian    | 3.90 | MSDSBA        |
|         5 | OS            | mbuffone@uncc.edu     | Mohana    | Buffone     | 3.42 | BSPSYC        |
|         6 | IS            | cquattrocchi@uncc.edu | Carme     | Quattrocchi | 2.89 | MAPSYC        |
|         7 | IS            | rmitchell@uncc.edu    | Rona      | Mitchell    | 3.16 | PhDHealthPSYC |
|         8 | IS            | jcapitani@uncc.edu    | Judicael  | Capitani    | 3.98 | BAPSYC        |
| 400300001 | IS            | khart4@uncc.edu       | Kevin     | Hart        | 3.70 | BAEN          |
| 400300002 | IS            | ejohns4@uncc.edu      | Erica     | Johnson     | 3.80 | BAED          |
| 400300007 | IN            | rekha@hotmail.com     | Rekha     | Seth        | 3.20 | MSMF          |
| 400300008 | IN            | shikha@yahoo.com      | Dev       | Patel       | 3.50 | MSBI          |
| 400300009 | IS            | frankger109@gmail.com | Frank     | Gerard      | 3.00 | MSGeo         |
| 400300010 | IN            | dpate110@gmail.com    | Dev       | Patel       | 3.00 | MSPsy         |
| 800800201 | IN            | rohitu@uncc.edu       | Rohit     | Upalaptthi  | 3.00 | MSSE          |
| 800800202 | IN            | yatink@uncc.edu       | Yatin     | Kiri        | 3.00 | MSSS          |
+-----------+---------------+-----------------------+-----------+-------------+------+---------------+
16 rows in set (0.00 sec)

*/

-- Busines Query 8
/*Displays the qualified Prospective Students based on their Interested Academic Degree*/

SELECT STU.studentID, STU.username, STU.firstName, STU.lastName, STU.email, STU.gpa, STU.degreeName, STU.testName, STU.testDate, STU.scoreVerbal, STU.scoreQuant, STU.scoreAWA
 
FROM 


(SELECT DEGREE.degreeName,testName,scoreVerbal,scoreQuant,scoreAWA,minGPA   

FROM DEGREE,DEGREE_REQUIREMENTS as DR, DRTESTSCORE as DT

WHERE DEGREE.degreeName=DR.degreeName AND DEGREE.degreeName=DT.degreeName) as DEG,


(SELECT S.studentID, S.username, S.firstName, S.lastName, S.email, S.gpa, I.degreeName, Test.testName, Test.testDate, Test.scoreVerbal, Test.scoreQuant, Test.scoreAWA  
 

FROM STUDENT AS S, INTERESTED_DEGREE AS I, TEST 
WHERE S.studentID= Test.studentID   AND   S.studentID= I.studentID ) as STU



WHERE DEG.degreeName=STU.degreeName AND STU.gpa >= DEG.minGPA  AND DEG.testName= STU.testName  AND DEG.scoreVerbal <= STU.scoreVerbal 

AND DEG.scoreQuant <= STU.scoreQuant AND DEG.scoreAWA <= STU.scoreAWA;

/*
Output:

*/


/*Team 5 Queries B9, B10*/
-- Busines Query 9


-- Recruiter can search current students at University, select those who are soon to graduate and suggest prospective higher education.

Select studentID,D.DegreeName,degreeDescription,credits from pinnacle.Degree D 
join INTERESTED_DEGREE I on D.DegreeName=I.DegreeName where studentID in
(SELECT  studentID FROM pinnacle.INTERESTED_DEGREE 
where studentID  in (select studentID from INTERNAL_STUDENT 
where TIMESTAMPDIFF(MONTH,CURDATE(),expectedGraduationDate) <= 6 ));

/*
Output:

+-----------+-----------+-----------+----------+-----------------------+------+------------+----------+------------+-------------+------------+----------+
| studentID | username  | firstName | lastName | email                 | gpa  | degreeName | testName | testDate   | scoreVerbal | scoreQuant | scoreAWA |
+-----------+-----------+-----------+----------+-----------------------+------+------------+----------+------------+-------------+------------+----------+
|         4 | jafar     | jafar     | jafarian | jafar@uncc.edu        | 3.90 | MSDSBA     | GRE      | 2013-04-21 |      163.00 |     163.00 |     5.00 |
| 400300001 | KHart4    | Kevin     | Hart     | khart4@uncc.edu       | 3.70 | BAEN       | SAT      | 0000-00-00 |      680.00 |     540.00 |   560.00 |
| 400300002 | EJohns9   | Erica     | Johnson  | ejohns4@uncc.edu      | 3.80 | BAED       | SAT      | 0000-00-00 |      610.00 |     570.00 |   520.00 |
| 400300007 | rekhas    | Rekha     | Seth     | rekha@hotmail.com     | 3.20 | MSMF       | GRE      | 2014-01-06 |      150.00 |     159.00 |     3.20 |
| 400300009 | fgerar109 | Frank     | Gerard   | frankger109@gmail.com | 3.00 | MSGeo      | GRE      | 2014-06-06 |      153.00 |     159.00 |     3.60 |
| 400300010 | dpate110  | Dev       | Patel    | dpate110@gmail.com    | 3.00 | MSPsy      | GRE      | 2014-10-06 |      160.00 |     160.00 |     3.60 |
+-----------+-----------+-----------+----------+-----------------------+------+------------+----------+------------+-------------+------------+----------+
6 rows in set (0.00 sec)
*/

-- Busines Query 10
-- Students can search for degrees offered and degree requirement for department of interest.

SELECT DG.degreeName,degreeDescription,fallDeadline,springDeadline,credits,totalIntake,minGPA,educationLevel 
FROM pinnacle.DEGREE DG,pinnacle.DEGREE_REQUIREMENTS DR where DG.degreeName = DR.degreeName;

/*
Output:

+------------+---------------------------------------------------------------------------------------------------------------------------------+---------------------+---------------------+---------+-------------+--------+----------------+
| degreeName | degreeDescription                                                                                                               | fallDeadline        | springDeadline      | credits | totalIntake | minGPA | educationLevel |
+------------+---------------------------------------------------------------------------------------------------------------------------------+---------------------+---------------------+---------+-------------+--------+----------------+
| BAECGR     | Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.       | 9999-03-01 23:59:59 | 9999-11-15 23:59:59 |     120 |        1057 |   2.00 | UD             |
| BAED       | Bachelors of Arts in Education                                                                                                  | 0000-00-00 00:00:00 | 0000-00-00 00:00:00 |     120 |        2000 |   3.00 | HS             |
| BAEN       | Bachelors of Arts in English                                                                                                    | 0000-00-00 00:00:00 | 0000-00-00 00:00:00 |     120 |        2000 |   3.00 | HS             |
| BSECGR     | Phasellus in felis. Donec semper sapien a libero. Nam dui.                                                                      | 9999-03-01 23:59:59 | 9999-11-15 23:59:59 |     120 |        1823 |   2.00 | UD             |
| MSBI       | Master of Science in Bioinformatics                                                                                             | 2015-03-15 00:00:00 | 2015-08-30 00:00:00 |      12 |          80 |   3.20 | MS             |
| MSCS       | Master of Science in Computer Science                                                                                           | 2015-06-15 00:00:00 | 2015-10-15 00:00:00 |      30 |          45 |   3.50 | MS             |
| MSDSBA     | Master of Science in Master of Science in Data Science and Business Analytic                                                    | 2015-07-01 00:00:00 | 2015-11-15 00:00:00 |      30 |          45 |   3.60 | MS             |
| MSECGR     | Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.                | 9999-03-01 23:59:59 | NULL                |      30 |          84 |   3.00 | MS             |
| MSGeo      | The M.S. in Geography at UNC Charlotte emphasizes the application of geo and theory to problem solving in contemporary society. | 2016-03-20 00:00:00 | 2016-09-30 00:00:00 |      36 |          40 |   3.00 | UG             |
| MSGIS      | Master of Science in GIS                                                                                                        | 2015-06-01 00:00:00 | 2015-10-01 00:00:00 |      30 |          40 |   3.80 | MS             |
| MSIS       | Master of Science in Information Systems                                                                                        | 2015-06-15 00:00:00 | 2015-10-15 00:00:00 |      30 |          45 |   3.40 | MS             |
| MSMF       | Master of Science in Mathematical Finance                                                                                       | 2015-03-01 00:00:00 | 2015-08-15 00:00:00 |      10 |         150 |   3.20 | MS             |
| MSPsy      | The Community Psychology Training Program is comprised of 3 separate but related components for students at different levels.   | 2016-03-30 00:00:00 | 2016-09-30 00:00:00 |      30 |          50 |   2.50 | UG             |
| MSSE       | Master of science in Software Engineering                                                                                       | 2015-12-12 11:55:55 | 2015-03-03 11:55:55 |      30 |           2 |   3.00 | UD             |
| MSSS       | Master of science in Security Systems                                                                                           | 2015-12-12 11:55:55 | 2015-03-03 11:55:55 |      30 |           2 |   3.00 | UD             |
| PhDECGR    | Etiam pretium iaculis justo. In hac habitasse platea dictumst. Etiam faucibus cursus urna.                                      | NULL                | 9999-11-15 23:59:59 |      78 |          17 |   3.50 | HS             |
+------------+---------------------------------------------------------------------------------------------------------------------------------+---------------------+---------------------+---------+-------------+--------+----------------+
16 rows in set (0.01 sec)

*/


